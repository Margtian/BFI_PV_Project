# BFI BBDD Scheme

Este repositorio contiene el esquema de base de datos exportado en HTML desde DbSchema.

## Ver online

La versión publicada está disponible en GitHub Pages:

👉 [Abrir esquema](https://<TU-USUARIO>.github.io/bfi-bbdd-scheme/)

> Al entrar se redirige al archivo `BFI BBDD Scheme.html`.
